using UnityEngine;
using TMPro;
using System.Collections.Generic;

public class ShopSystem : MonoBehaviour
{
    [Header("UI References")]
    public TMP_Text goldText;
    public RectTransform arrow;

    [Header("Upgrade Costs")]
    public int attackUpgradeCost = 50;
    public int defenseUpgradeCost = 50;
    public int spellDamageUpgradeCost = 50;

    [Header("Upgrade Amounts")]
    public int attackIncreaseAmount = 5;
    public int defenseIncreaseAmount = 5;
    public int spellDamageIncreaseAmount = 5;

    private int currentSelection = 0;
    private List<string> shopOptions = new List<string>
    {
        "Buy Attack (+5)",
        "Buy Defense (+5)",
        "Buy Ability Power (+5)",
        "Next Battle"
    };

    // X positions for arrow (horizontal layout)
    private List<float> arrowXPositions = new List<float>
    {
        -5.22f,
        -1.23f,
        2.5f,
        7.5f
    };

    void Start()
    {
        UpdateUI();
        UpdateArrowPosition();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            currentSelection = MenuLeft();
            UpdateArrowPosition();
        }

        if (Input.GetKeyDown(KeyCode.D))
        {
            currentSelection = MenuRight();
            UpdateArrowPosition();
        }

        if (Input.GetKeyDown(KeyCode.J))
        {
            HandleChoice();
        }
    }

    private int MenuLeft() => currentSelection == 0 ? shopOptions.Count - 1 : currentSelection - 1;
    private int MenuRight() => currentSelection == shopOptions.Count - 1 ? 0 : currentSelection + 1;

    void UpdateArrowPosition()
    {
        if (arrow != null && currentSelection < arrowXPositions.Count)
        {
            Vector2 pos = arrow.anchoredPosition;
            pos.x = arrowXPositions[currentSelection];
            arrow.anchoredPosition = pos;
        }
    }

    void UpdateUI()
    {
        if (GameSession.gs != null)
        {
            goldText.text = $"{GameSession.gs.currentGold}";
        }
    }

    void HandleChoice()
    {
        switch (currentSelection)
        {
            case 0:
                BuyAttackUpgrade();
                break;
            case 1:
                BuyDefenseUpgrade();
                break;
            case 2:
                BuySpellDamageUpgrade();
                break;
            case 3:
                LeaveShop();
                break;
        }
    }

    void BuyAttackUpgrade()
    {
        if (GameSession.gs == null)
        {
            Debug.LogError("GameSession not found!");
            return;
        }

        if (GameSession.gs.SpendGold(attackUpgradeCost))
        {
            GameSession.gs.playerMember.currentAttackDamage += attackIncreaseAmount;
            Debug.Log($"Attack increased! New attack: {GameSession.gs.playerMember.currentAttackDamage}");
            UpdateUI();
        }
        else
        {
            Debug.Log("Not enough gold!");
        }
    }

    void BuyDefenseUpgrade()
    {
        if (GameSession.gs == null)
        {
            Debug.LogError("GameSession not found!");
            return;
        }

        if (GameSession.gs.SpendGold(defenseUpgradeCost))
        {
            GameSession.gs.playerMember.currentDefense += defenseIncreaseAmount;
            Debug.Log($"Defense increased! New defense: {GameSession.gs.playerMember.currentDefense}");
            UpdateUI();
        }
        else
        {
            Debug.Log("Not enough gold!");
        }
    }

    void BuySpellDamageUpgrade()
    {
        if (GameSession.gs == null)
        {
            Debug.LogError("GameSession not found!");
            return;
        }

        if (GameSession.gs.SpendGold(spellDamageUpgradeCost))
        {
            GameSession.gs.playerMember.currentAbilityPower += spellDamageIncreaseAmount;
            Debug.Log($"Spell damage increased! New ability power: {GameSession.gs.playerMember.currentAbilityPower}");
            UpdateUI();
        }
        else
        {
            Debug.Log("Not enough gold!");
        }
    }

    void LeaveShop()
    {
        if (GameSession.gs != null)
        {
            // Reinitialize enemy for next battle
            GameSession.gs.InitializeEnemy();
        }

        // Load back to battle
        UnityEngine.SceneManagement.SceneManager.LoadScene("Turn Based");
    }
}
